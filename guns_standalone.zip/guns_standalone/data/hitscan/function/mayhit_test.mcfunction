# 히트박스 높이를 얻기 위해 다양한 y 오프셋에서 체크
# 헤드샷: 엔티티 히트박스 맨 위 - 0.2 ~ 맨 위 (위에서 1블럭)
# 몸샷: 그 아래

# 플레이어 (1.8m): 헤드 = 1.6~1.8m
execute positioned ~ ~-1.8 ~ as @a[limit=1,distance=..0.5,tag=!shooter] run return run tag @s add headshot
execute positioned ~ ~-1.6 ~ as @a[limit=1,distance=..0.5,tag=!shooter] run return run tag @s add headshot
execute positioned ~ ~-1.3 ~ as @a[limit=1,distance=..0.5,tag=!shooter] run return run tag @s add bodyshot
execute positioned ~ ~-0.9 ~ as @a[limit=1,distance=..0.5,tag=!shooter] run return run tag @s add bodyshot
execute positioned ~ ~-0.4 ~ as @a[limit=1,distance=..0.5,tag=!shooter] run return run tag @s add bodyshot

# 모든 non-player 엔티티 - 히트박스 높이 추정
# 키 큰 몹 (husk, zombie, skeleton 등 ~1.95m): 헤드 = 1.7~1.95
execute positioned ~ ~-1.9 ~ as @e[limit=1,distance=..0.5,type=!player,type=!item,type=!item_display,type=!block_display,type=!text_display,type=!interaction,type=!area_effect_cloud,type=!armor_stand,type=!marker] run return run tag @s add headshot
execute positioned ~ ~-1.7 ~ as @e[limit=1,distance=..0.5,type=!player,type=!item,type=!item_display,type=!block_display,type=!text_display,type=!interaction,type=!area_effect_cloud,type=!armor_stand,type=!marker] run return run tag @s add headshot
execute positioned ~ ~-1.4 ~ as @e[limit=1,distance=..0.5,type=!player,type=!item,type=!item_display,type=!block_display,type=!text_display,type=!interaction,type=!area_effect_cloud,type=!armor_stand,type=!marker] run return run tag @s add bodyshot
execute positioned ~ ~-1.0 ~ as @e[limit=1,distance=..0.5,type=!player,type=!item,type=!item_display,type=!block_display,type=!text_display,type=!interaction,type=!area_effect_cloud,type=!armor_stand,type=!marker] run return run tag @s add bodyshot
execute positioned ~ ~-0.6 ~ as @e[limit=1,distance=..0.5,type=!player,type=!item,type=!item_display,type=!block_display,type=!text_display,type=!interaction,type=!area_effect_cloud,type=!armor_stand,type=!marker] run return run tag @s add bodyshot
execute positioned ~ ~-0.2 ~ as @e[limit=1,distance=..0.5,type=!player,type=!item,type=!item_display,type=!block_display,type=!text_display,type=!interaction,type=!area_effect_cloud,type=!armor_stand,type=!marker] run return run tag @s add bodyshot

return fail
