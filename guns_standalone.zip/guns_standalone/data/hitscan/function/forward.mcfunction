execute if score #forward dummy matches 100.. run return fail
execute unless block ~ ~ ~ #dummy:penetrable positioned ^ ^ ^-0.5 run return run function hitscan:inblockb0
execute if entity @e[distance=..2,type=!player,type=!item,type=!item_display,type=!block_display,type=!text_display,type=!interaction,type=!area_effect_cloud,type=!armor_stand,type=!marker] run function hitscan:mayhit
execute if entity @a[distance=..2,tag=!shooter] run function hitscan:mayhit
scoreboard players add #forward dummy 1
execute positioned ^ ^ ^0.7 run function hitscan:forward
