scoreboard players set #hit dummy 0
execute if score #hit dummy matches 0 store success score #hit dummy positioned ^ ^ ^-1 run function hitscan:mayhit_test
execute if score #hit dummy matches 0 store success score #hit dummy positioned ^ ^ ^-0.6 run function hitscan:mayhit_test
execute if score #hit dummy matches 0 store success score #hit dummy positioned ^ ^ ^-0.2 run function hitscan:mayhit_test
execute if score #hit dummy matches 0 store success score #hit dummy positioned ^ ^ ^0.2 run function hitscan:mayhit_test
execute if score #hit dummy matches 0 store success score #hit dummy positioned ^ ^ ^0.6 run function hitscan:mayhit_test
execute if score #hit dummy matches 0 store success score #hit dummy positioned ^ ^ ^1 run function hitscan:mayhit_test

execute if score #hit dummy matches 1 run function hitscan:tagdmg