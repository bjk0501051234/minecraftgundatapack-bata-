scoreboard players set #forward dummy 0
$execute rotated ~$(Rotation_x) ~$(Rotation_y) run function hitscan:forward
