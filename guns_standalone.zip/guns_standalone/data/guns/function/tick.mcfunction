function riding:riding
execute as @a at @s run function guns:ammo_pickup
execute as @a at @s run function guns:input_handler
execute as @a at @s if score #reloading dummy matches 0 if items entity @s weapon.offhand #dummy:reloadable run function guns:reload_controll
