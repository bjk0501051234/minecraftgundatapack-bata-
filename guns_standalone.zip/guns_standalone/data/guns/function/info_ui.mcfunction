execute unless entity @e[tag=ui1,distance=..5,limit=1] run return fail
execute if score #isgetgun_pistol dummy matches 0 if score #isgetgun_ak dummy matches 0 run return fail
execute if score #hold_weapon dummy matches 0 as @e[tag=ui1,distance=..5,limit=1] run data merge entity @s {text:""}
execute if score #hold_weapon dummy matches 0 as @e[tag=ui2,distance=..5,limit=1] run data merge entity @s {text:""}
execute if score #hold_weapon dummy matches 0 as @e[tag=ui3,distance=..5,limit=1] run data merge entity @s {text:""}
execute if score #hold_weapon dummy matches 0 run return fail
execute as @e[tag=ui1,distance=..5,limit=1] run data merge entity @s {text:[{text:"ㅡㅡㅡㅡㅡㅡ\n\n\n\n\n\n\n\n\n\n\n\n\n"},{storage:guninfo,nbt:text0}]}
execute as @e[tag=ui2,distance=..5,limit=1] run data merge entity @s {text:[{text:"ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"},{storage:guninfo,nbt:text1}]}
execute if score #hold_weapon dummy matches 1 as @e[tag=ui3,distance=..5,limit=1] run data merge entity @s {text:[{text:"ㅡㅡㅡㅡㅡ\n\n\n\n\n\n\n\n\n\n\n\n"},{score:{objective:dummy,name:"#pistol_remain_bullet"}}," / inf"]}
execute if score #hold_weapon dummy matches 2 as @e[tag=ui3,distance=..5,limit=1] run data merge entity @s {text:[{text:"ㅡㅡㅡㅡㅡ\n\n\n\n\n\n\n\n\n\n\n\n"},{score:{objective:dummy,name:"#ak_remain_bullet"}}," / ",{score:{objective:dummy,name:"#ak_remain_mag"}}]}
