scoreboard objectives add dummy dummy
scoreboard objectives add cal dummy
scoreboard objectives add riding dummy
scoreboard objectives add health health
scoreboard objectives add timer dummy
scoreboard players set #2 cal 2
scoreboard players set #4 cal 4
scoreboard players set #10 cal 10
scoreboard players set #20 cal 20
scoreboard players set #80 cal 80
team add enemy
# 기존 마운트에서 모두 내리기
execute as @a run ride @s dismount
execute as @a run function guns:score_init
tellraw @a {"text":"[총기팩] /function guns:give/ak | guns:give/pistol | guns:give/ammo | guns:give/all","color":"green"}
scoreboard players set #1000 cal 1000
