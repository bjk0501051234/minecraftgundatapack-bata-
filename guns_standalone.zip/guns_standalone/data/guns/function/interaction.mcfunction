execute as @a at @s run function guns:input_handler
