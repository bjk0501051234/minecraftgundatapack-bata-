execute if score #zoom dummy matches 0 store result storage random Rotation_x double 0.01 run random value -300..300
execute if score #zoom dummy matches 0 store result storage random Rotation_y double 0.01 run random value -300..300
execute if score #zoom dummy matches 1 store result storage random Rotation_x double 0.01 run random value -30..30
execute if score #zoom dummy matches 1 store result storage random Rotation_y double 0.01 run random value -30..30
execute if score #pistol_remain_bullet dummy matches 0 run playsound minecraft:block.note_block.hat weather @s ~ ~ ~ 1 1.5
execute if score #pistol_remain_bullet dummy matches 0 run return fail
execute anchored eyes run function hitscan:start with storage random
execute if score #zoom dummy matches 0 run rotate @s ~ ~-2
execute if score #zoom dummy matches 1 run rotate @s ~ ~-0.7
playsound entity.creeper.hurt weather @s ~ ~ ~ 1 1.7
playsound entity.creeper.death weather @s ~ ~ ~ 1 1.3
scoreboard players remove #pistol_remain_bullet dummy 1
execute if score #pistol_remain_bullet dummy matches 1 run data remove entity @e[tag=magg_cube,limit=1,type=block_display] block_state
execute if score #pistol_remain_bullet dummy matches 1 run data remove entity @e[tag=magc_cube,limit=1,type=block_display] block_state
execute if score #zoom dummy matches 0 run function guns:pistol/schedule/nzf
execute if score #zoom dummy matches 0 run scoreboard players set #shooting dummy 1
execute if score #zoom dummy matches 1 run function guns:pistol/schedule/zf
execute if score #zoom dummy matches 1 run scoreboard players set #shooting dummy 1
