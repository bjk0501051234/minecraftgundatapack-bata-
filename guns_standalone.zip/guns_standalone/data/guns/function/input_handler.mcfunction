# @s = 플레이어, at @s = 플레이어 위치
execute unless entity @e[tag=weapon,distance=..5,limit=1] run return fail

# 장전 중: 클릭 소비 후 종료
execute if score #reloading dummy matches 1 as @e[tag=weapon,distance=..5,limit=1] on attacker run data remove entity @e[tag=weapon,distance=..5,limit=1] attack
execute if score #reloading dummy matches 1 as @e[tag=weapon,distance=..5,limit=1] on target run data remove entity @e[tag=weapon,distance=..5,limit=1] interaction
execute if score #reloading dummy matches 1 run return fail

# hold_weapon 저장 → 슬롯 감지
scoreboard players operation #holded_weapon dummy = #hold_weapon dummy
function guns:choose_weapon

# swap 쿨타임: 클릭 소비 + holded 강제 sync (빠른 교체 모델 불일치 방지)
execute unless score #swap_cool dummy matches 0 as @e[tag=weapon,distance=..5,limit=1] on attacker run data remove entity @e[tag=weapon,distance=..5,limit=1] attack
execute unless score #swap_cool dummy matches 0 as @e[tag=weapon,distance=..5,limit=1] on target run data remove entity @e[tag=weapon,distance=..5,limit=1] interaction
execute unless score #swap_cool dummy matches 0 run scoreboard players remove #swap_cool dummy 1
execute unless score #swap_cool dummy matches 0 run scoreboard players operation #holded_weapon dummy = #hold_weapon dummy
execute unless score #swap_cool dummy matches 0 run return fail

# 무기 교체 감지 (swap_cool=0 이고 슬롯 바뀌었으면)
execute unless score #hold_weapon dummy = #holded_weapon dummy run function guns:weaponswap

# ==== 좌클릭 ====
# 발사 시도 (shooting=0 일 때만)
execute if score #shooting dummy matches 0 if score #hold_weapon dummy matches 1 as @e[tag=weapon,distance=..5,limit=1] on attacker at @s run function guns:pistol/shoot
execute if score #shooting dummy matches 0 if score #hold_weapon dummy matches 2 as @e[tag=weapon,distance=..5,limit=1] on attacker at @s run function guns:ak/shoot

# ★ attack 데이터 무조건 소비 (발사 여부 무관) → 1클릭=1발 보장 ★
# 연사(꾹 클릭)는 인터랙션 엔티티 특성상 지원 안됨
# (interaction entity는 click당 1회만 attack 생성)
execute as @e[tag=weapon,distance=..5,limit=1] on attacker run data remove entity @e[tag=weapon,distance=..5,limit=1] attack

# ==== 우클릭 ====
execute if score #hold_weapon dummy matches 1 as @e[tag=weapon,distance=..5,limit=1] on target run function guns:pistol/zoom
execute if score #hold_weapon dummy matches 2 as @e[tag=weapon,distance=..5,limit=1] on target run function guns:ak/zoom
execute as @e[tag=weapon,distance=..5,limit=1] on target run data remove entity @e[tag=weapon,distance=..5,limit=1] interaction

# UI
function guns:info_ui
