scoreboard players set #stuck riding 0
scoreboard players set #on_ground riding 1
scoreboard players set #y_velocity riding 0
schedule clear riding:y_velo_control