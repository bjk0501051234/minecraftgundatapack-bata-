execute as @a anchored eyes at @s run tp @e[tag=tracker,distance=..50,limit=1] ^ ^ ^ ~ ~
data modify storage minecraft:riding bpos set from entity @e[tag=layer0,limit=1] Pos
scoreboard players set #ws riding 0
scoreboard players set #da riding 0

execute as @a if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"type_specific":{"type":"minecraft:player","input":{"forward":true}}}} run scoreboard players add #ws riding 1
execute as @a if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"type_specific":{"type":"minecraft:player","input":{"backward":true}}}} run scoreboard players remove #ws riding 1
execute as @a if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"type_specific":{"type":"minecraft:player","input":{"right":true}}}} run scoreboard players add #da riding 1
execute as @a if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"type_specific":{"type":"minecraft:player","input":{"left":true}}}} run scoreboard players remove #da riding 1

execute if score #zoom dummy matches 0 if score #ws riding matches 1 if score #da riding matches 0 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~ 0 run tp ^ ^ ^0.29
execute if score #zoom dummy matches 0 if score #ws riding matches -1 if score #da riding matches 0 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~180 0 run tp ^ ^ ^0.29
execute if score #zoom dummy matches 0 if score #ws riding matches 0 if score #da riding matches 1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~90 0 run tp ^ ^ ^0.29
execute if score #zoom dummy matches 0 if score #ws riding matches 0 if score #da riding matches -1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~-90 0 run tp ^ ^ ^0.29
execute if score #zoom dummy matches 0 if score #ws riding matches 1 if score #da riding matches -1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~-45 0 run tp ^ ^ ^0.29
execute if score #zoom dummy matches 0 if score #ws riding matches 1 if score #da riding matches 1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~45 0 run tp ^ ^ ^0.29
execute if score #zoom dummy matches 0 if score #ws riding matches -1 if score #da riding matches -1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~-135 0 run tp ^ ^ ^0.29
execute if score #zoom dummy matches 0 if score #ws riding matches -1 if score #da riding matches 1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~135 0 run tp ^ ^ ^0.29

execute if score #zoom dummy matches 1 if score #ws riding matches 1 if score #da riding matches 0 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~ 0 run tp ^ ^ ^0.15
execute if score #zoom dummy matches 1 if score #ws riding matches -1 if score #da riding matches 0 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~180 0 run tp ^ ^ ^0.15
execute if score #zoom dummy matches 1 if score #ws riding matches 0 if score #da riding matches 1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~90 0 run tp ^ ^ ^0.15
execute if score #zoom dummy matches 1 if score #ws riding matches 0 if score #da riding matches -1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~-90 0 run tp ^ ^ ^0.15
execute if score #zoom dummy matches 1 if score #ws riding matches 1 if score #da riding matches -1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~-45 0 run tp ^ ^ ^0.15
execute if score #zoom dummy matches 1 if score #ws riding matches 1 if score #da riding matches 1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~45 0 run tp ^ ^ ^0.15
execute if score #zoom dummy matches 1 if score #ws riding matches -1 if score #da riding matches -1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~-135 0 run tp ^ ^ ^0.15
execute if score #zoom dummy matches 1 if score #ws riding matches -1 if score #da riding matches 1 as @e[tag=layer0,limit=1] at @s rotated as @a[limit=1] rotated ~135 0 run tp ^ ^ ^0.15

execute at @e[tag=layer0,limit=1] run function riding:stuck
execute if score #stuck riding matches 1 as @e[tag=layer0,limit=1] at @s run function riding:backtrack

execute if score #on_ground riding matches 1 as @a if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"type_specific":{"type":"minecraft:player","input":{"jump":true}}}} run function riding:y_velo_control
execute if score #on_ground riding matches 1 as @e[tag=layer0,limit=1] at @s if block ~-0.299 ~-0.601 ~-0.299 #dummy:penetrable if block ~0.299 ~-0.601 ~-0.299 #dummy:penetrable if block ~-0.299 ~-0.601 ~0.299 #dummy:penetrable if block ~0.299 ~-0.601 ~0.299 #dummy:penetrable run function riding:falling

execute at @e[tag=layer0,limit=1] run function riding:stuck
execute if score #stuck riding matches 1 as @e[tag=layer0,limit=1] run tp @s @a[limit=1]

ride @a mount @e[tag=layer0,limit=1]
